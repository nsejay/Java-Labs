package lab03stringbagsummer2019;

/**
 * StringBag Class for Lab 3
 * @author Michael Main / Stephen T. Brower<stephen.brower@raritanval.edu>
 *         Updated by: Linda Yang
 *         Modified by: Sejay Noupin
 */
public class StringBag
{
    private String[] data;
    private int numElements;

    /**
     * Constructor
     * @param initialCapacity   to set initial size of array
     */
    public StringBag(int initialCapacity)
    {
        data = new String[initialCapacity];
        numElements = 0;
    }


    /**
     * No-Arg Constructor
     */
    public StringBag()
    {
       data = new String[10];
       numElements = 0;
    }

    /**
     * getCapacity method   This method is to retrieve the length of the array
     * @return  returns length of array
     */
    public int getCapacity()
    {
        return data.length;// put code here
    }

    /**
     * getSize method    This method is to retrieve the number of 
     *                   filled elements in the array
     * @return    returns number of filled elements in the array
     */
    public int getSize()
    {
        return numElements;
    }

    /**
     * add method    This method is to add an element to the array
     * @param newElement allows String input of new element to array
     */
    public void add(String newElement)
    {
        int i;
        int n;
        String hold;
        
        if (numElements == data.length)
            enlargeArray();

        // this version adds to the end of the array
        // have it maintain a..z order for extra credit
        data[numElements] = new String(newElement);
        
        for (i = 1; i < data.length; i++) 
        {
            for ( n = 1; n < data.length; n++) 
            {
                if (data[n - 1].compareToIgnoreCase(data[n]) > 0) 
                {
                    hold = data[n - 1];
                    data[n - 1] = data[n];
                    data[n] = hold;
                }
            }
        }
        numElements++;
    }

    /**
     * enlargeArray method   This method is to increase 
     *                       the length of the array in 
     *                       order to be able to add more elements
     */
    private void enlargeArray()
    {
        String[] newArray = new String[data.length*2 + 1];

        for (int i = 0; i < data.length; i++)
            newArray[i] = new String(data[i]);

        data = newArray;
    }


    /**
     * exists method  This method tells you if a desired element exists in the array
     * @param target  Allows input for desired element existence in array
     * @return    true/false as to whether element exists in array
     */
    public boolean exists(String target)
    {
        boolean found = false;
        int i = 0;

        while (!found && i < numElements)
            if (data[i].equalsIgnoreCase(target))
                found = true;
            else
                i++;

        return found;
    }

    /**
     * countOccurrences method     This method counts how many times
     *                             a specific element appears in the array
     * @param target   Allows input for specific element that 
     *                 knowledge of occurrence is necessary
     * @return   returns number of times that element appears in array
     */
    public int countOccurrences(String target)
    {
        int numOccur = 0;

       for(int i = 0; i < numElements; i++)
       {
           if(data[i].equalsIgnoreCase(target))
               numOccur++;
       }

        return numOccur;
    }

    /**
     * remove method   This method removes element from array
     * @param target   Allows input for a specific element to be removed
     * @return   returns to that specified element was found
     */
    public boolean remove(String target)
    {
        boolean found = false;
        int i = 0;
        int n = 0;
        String hold;

        while (!found && i < numElements)
        {
            if (data[i].equalsIgnoreCase(target))
                found = true;
            else
                i++;
        }

        if (found)
        {
            for (i = 1; i < data.length; i++) 
            {
                for (n = 1; n < data.length; n++) 
                {
                    if (data[n - 1].compareToIgnoreCase(data[n]) > 0) 
                    {
                        hold = data[n - 1];
                        data[n - 1] = data[n];
                        data[n] = hold;
                    }
                }
            }
            numElements--;
        }

        // have it maintain order for extra extra credit

        return found;
    }

    /**
     * iteratorPrototype method creates a copy of the data and
     * creates an iterator from the copied array
     * @return an iterator using ListerPrototype1 created from a copy of data
     */
    public ListerPrototype1 iteratorPrototype()
    {
        // since the data array is partially filled, create a copy
        // that is just a size of the number of elements filled
        String[] copyToReturn = new String[numElements];

        // loop through array and copy data to copy array
        for (int i = 0; i< numElements; i++)
            copyToReturn[i] = data[i];

        // instantiate a ListerProtoype1 using the copied array
        return new ListerPrototype1(copyToReturn);
    }
}