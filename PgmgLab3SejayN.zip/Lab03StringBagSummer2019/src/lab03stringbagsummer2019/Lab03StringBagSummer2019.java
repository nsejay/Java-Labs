package lab03stringbagsummer2019;

import java.util.Scanner;

/**
 *
 * @author Stephen T. Brower<stephen.brower@raritanval.edu>
 */
public class Lab03StringBagSummer2019
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        // declare variables
        StringBag fruitBag = new StringBag(4);
        String fruitToAdd, fruitToFind, fruitToDelete;

        // Create a Scanner object to read input.
        Scanner keyboard = new Scanner(System.in);

        displayBag("\nfruitBag upon startup",fruitBag);

        System.out.print("\nEnter fruit name to add ( stop to stop adding, exit to exit): ");
        fruitToAdd = keyboard.nextLine();

        while ( !(fruitToAdd.equalsIgnoreCase("stop") || fruitToAdd.equalsIgnoreCase("exit")) )
        {
            // add fruit to bag
            fruitBag.add(fruitToAdd);

            displayBag("\nfruitBag after adding "+fruitToAdd,fruitBag);

            // get another fruit
            System.out.print("\nEnter fruit name to add ( stop to stop adding, exit to exit): ");
            fruitToAdd = keyboard.nextLine();
        }

        displayBag("\nfruitBag when done adding ",fruitBag);

        if ( !(fruitToAdd.equalsIgnoreCase("Exit")) )
        {

            System.out.print("\nEnter fruit name to find ( stop to stop looking, exit to exit): ");
            fruitToFind = keyboard.nextLine();

            while ( !(fruitToFind.equalsIgnoreCase("stop") || fruitToFind.equalsIgnoreCase("exit")) )
            {
                // try to find fruit
                if (fruitBag.exists(fruitToFind))
                    System.out.println("\n" + fruitToFind + " exists in fruitBag " +
                            "# of times: " + fruitBag.countOccurrences(fruitToFind));
                else
                    System.out.println("\n" + fruitToFind + " is not in fruitBag " +
                            "# of times: " + fruitBag.countOccurrences(fruitToFind));

                displayBag("\nfruitBag after searching "+fruitToFind,fruitBag);

                // get another fruit
                System.out.print("\nEnter fruit name to find ( stop to stop searching, exit to exit): ");
                fruitToFind = keyboard.nextLine();
            }

            displayBag("\nfruitBag when done searching ",fruitBag);

            if ( !(fruitToFind.equalsIgnoreCase("Exit")) )
            {

                System.out.print("\n\nEnter fruit name to delete ( exit to stop deleting): ");
                fruitToDelete = keyboard.nextLine();

                while ( !(fruitToDelete.equalsIgnoreCase("exit")) )
                {
                    // try to remove fruit
                    if (fruitBag.remove(fruitToDelete))
                        System.out.println("\n" + fruitToDelete + " was removed from fruitBag");
                    else
                        System.out.println("\n" + fruitToDelete + " wasn't removed");

                    displayBag("\nfruitBag after deleting "+fruitToDelete,fruitBag);

                    // get another fruit
                    System.out.print("\nEnter fruit name to delete ( exit to stop deleting): ");
                    fruitToDelete = keyboard.nextLine();
                }

                displayBag("\nfruitBag when done deleting",fruitBag);
            }
        }

        System.out.println("\nGoodbye!");
    }
    /**
        the displayBag method displays the StringBag
        @param heading a String to display before the bag
        @param aBag the StringBag to display
    */
    public static void displayBag(String heading, StringBag aBag)
    {
        System.out.println(heading);
        System.out.print("cap="+aBag.getCapacity()+" n="+aBag.getSize()+" Bag: ");

        if (aBag.getSize() == 0)
        {
            System.out.println("Empty");//: Double Check if empty [ " + aBag + "]");
        }
        else
        {
            //System.out.println("Not Empty: Check [ " + aBag + "]");
            ListerPrototype1 stringLister = aBag.iteratorPrototype();
            while (stringLister.hasNext())
            {
                String displayString = stringLister.next();
                System.out.print("{" + displayString + "}");
                if (stringLister.hasNext())
                    System.out.print( ", ");
            }
            System.out.println();

        }


    }
}
