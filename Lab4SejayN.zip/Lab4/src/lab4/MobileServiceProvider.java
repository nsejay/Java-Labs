package lab4;

/**
 *
 * @author Sejay Noupin
 */
public class MobileServiceProvider 
{
    private char customerPackage;
    private int numberOfMinutesUsed;
    
    public MobileServiceProvider (char newCustomerPackage, 
                                  int newNumberOfMinutesUsed)
    {
        customerPackage = newCustomerPackage;
        numberOfMinutesUsed = newNumberOfMinutesUsed;                
    }
    public char getCustomerPackage()
    {
        return customerPackage;
    }
    public int getNumberOfMinutesUsed()
    {
        return numberOfMinutesUsed;
    }
    public void setCustomerPackage(char newCustomerPackage)
    {
        customerPackage = newCustomerPackage;
    }
    public void setNumberOfMinutesUsed(int newNumberOfMinutesUsed)
    {
        numberOfMinutesUsed = newNumberOfMinutesUsed;
    }
    public double totalCharges()
    {
        if ((customerPackage == 'A' || customerPackage =='a') 
           && (numberOfMinutesUsed <= 450))
        {
            return 39.99;
        }
        else if ((customerPackage =='A' || customerPackage == 'a') 
                && (numberOfMinutesUsed > 450))
        {
            double result = 39.99 + (numberOfMinutesUsed - 450)*.45;
            return result;
        }
        else if ((customerPackage == 'B' || customerPackage == 'b') 
                && (numberOfMinutesUsed <= 900))
        {
            return 59.99;
        }
        else if ((customerPackage == 'B' || customerPackage == 'b')
                && (numberOfMinutesUsed > 900))
        {
            double result = 59.99 + (numberOfMinutesUsed - 900)*.40;
            return result;
        }
        else
            return 69.99;
    }
}
