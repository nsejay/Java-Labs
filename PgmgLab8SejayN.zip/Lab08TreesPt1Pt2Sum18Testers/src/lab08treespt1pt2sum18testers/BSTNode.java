package lab08treespt1pt2sum18testers;

/**
 *
 * @author Sejay Noupin
 */
public class BSTNode<E>
{
    private E data;
    private BSTNode<E> left;
    private BSTNode<E> right;
    
    /**
     * Constructor
     * @param newData allows input for data to be entered
     * @param newLeft allows input for which node if any to be linked to from the left
     * @param newRight allows input for which node if any to be linked to from the right
     */
    public BSTNode(E newData, BSTNode<E> newLeft, BSTNode<E> newRight)
    {
        data = newData;
        left = newLeft;
        right = newRight;
    }
    /**
     * The getData method retrieves the data that exists at a specific node
     * @return element that exists at a given node
     */
    public E getData()
    {
        return data;
    }
    /**
     * The getLeft method retrieves the node to the left of the current node
     * @return the node to the left of the current node
     */
    public BSTNode<E> getLeft()
    {
        return left;
    }
    /**
     * The gerRight method retrieves the node to the right of the current node
     * @return  node to the right of the current node
     */
    public BSTNode<E> getRight()
    {
        return right;
    }
    /**
     * The getRightMostData method retrieves the data that exists in the right-most node
     * @return the data that exists at the right-most node
     */
    public E getRightMostData()
    {
        if(right == null)
            return data;
        else
            return right.getRightMostData();
    }
    /**
     * The inorderPrint method prints from the left-most node 
     * to the right-most node based on the selected sub-Tree
     */
    public void inorderPrint()
    {
        if(left != null)
            left.inorderPrint();
        
        System.out.println(data);
        
        if (right != null)
            right.inorderPrint();
    }
    /**
     * The removeRightmost method removes the right-most node from the tree
     * @return either the left node or the right most node that was removed
     */
    public BSTNode<E> removeRightmost()
    {
        if(right == null)
            return left;
        else
        {
            right = right.removeRightmost();
            return this;
        }
    }
    /**
     * The setData method allows new data to be entered into a node 
     * @param newData allows input for new data to be entered
     */
    public void setData(E newData)
    {
        data = newData;
    }
    /**
     * The setLeft method allows a new link to be created to the left of the given node
     * @param newLeft allows input for node that will be connected to the left of given node
     */
    public void setLeft(BSTNode<E> newLeft)
    {
        left = newLeft;
    }
    /**
     * The setRight method allows a new link to be created to the right of the given node
     * @param newRight allows input for node that will be connected to the right of given node
     */
    public void setRight(BSTNode<E> newRight)
    {
        right = newRight;
    }
    
    public int count()
    {
        int valueToReturn = 1;
        
        if(left != null)
            left.count();
        valueToReturn++;
        if(right != null)
            right.count();
        
        return valueToReturn;
    }
}
