package lab08treespt1pt2sum18testers;

/**
 *
 * @author Sejay Noupin
 */
public class Tree<E extends Comparable<E>>
{
    private BSTNode<E> root;
    private int numItems;
    
    /**
     * No-arg constructor initializes root to null and number of items to 0
     */
    public Tree()
    {
        root = null;
        numItems = 0;
    }
    /**
     * The add method adds an element to the tree following 
     * established rules for the reprsentation of trees
     * @param element allows input for desired element to be added
     */
    public void add(E element)
    {
        BSTNode<E> cursor;
        boolean done;
        
        if(root == null)
            root = new BSTNode<E>(element,null,null);
        else
        {
            cursor = root; 
            done = false;
            
            while(!done)
            {
                if(element.compareTo(cursor.getData()) < 0)
                {
                    if(cursor.getLeft() == null)
                    {
                        cursor.setLeft(new BSTNode<E>(element,null,null));
                        done = true;
                    }
                    else
                        cursor = cursor.getLeft();
                }
                else
                {
                    if(cursor.getRight() == null)
                    {
                        cursor.setRight(new BSTNode<E>(element,null,null));
                        done = true;
                    }
                    else
                        cursor = cursor.getRight();
                }
            }
        }
        numItems++;
    }
    /**
     * The remove method removes an element from the tree 
     * while keeping proper tree format
     * @param element allows input for desired element to be removed
     * @return whether or not element was able to be removed
     */
    public boolean remove(E element)
    {
        boolean found = false;
        BSTNode<E> cursor = root, parentOfCursor = null;
        
        while(cursor != null && !found)
        {
            if(cursor.getData().equals(element))
                found = true;
            else if(element.compareTo(cursor.getData()) < 0)
            {
                parentOfCursor = cursor;
                cursor = cursor.getLeft();
            }
            else
            {
                parentOfCursor = cursor;
                cursor = cursor.getRight();
            }
        }
        if(cursor == null)
            found = false;
        else if(cursor == root && cursor.getLeft() == null)
        {
            root = root.getRight();
            numItems--;
        }
        else if(cursor != root && cursor.getLeft() == null)
        {
            if(cursor == parentOfCursor.getLeft())
                parentOfCursor.setLeft(cursor.getRight());
            else
                parentOfCursor.setRight(cursor.getLeft());
            numItems--;
        }
        else
        {
            cursor.setData(cursor.getLeft().getRightMostData());
            cursor.setLeft(cursor.getLeft().removeRightmost());
            numItems--;
        }
        
        return found;
    }
    /**
     * The size method returns the number of elements in the tree
     * @return number of elements in the tree
     */
    public int size()
    {
        return numItems;
    }
    /**
     * The printTree method displays the tree from the 
     * left-most node to the right-most node
     */
    public void printTree()
    {
        if(root != null)
            root.inorderPrint();
    }
    public int count()
    {
        if (root == null)
            return 0;
        else
            return root.count();
    }
}
