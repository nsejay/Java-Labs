package lab04stringlinkedbagsum19;

/**
 *
 * @author Sejay Noupin
 */
public class StringLinkedBag 
{
    private StringNode head;
    private StringNode tail;
    private int numElements;
    
    /**Constructor
     * No-arg constructor sets all parameters to 0 in order to begin linked list
     */
    public StringLinkedBag()
    {
        head = null;
        tail = null;
        numElements = 0;
    }
    /**
     * The getSize method shows the current size of the linked list
     * @return the number of elements in the linked list
     */
    public int getSize()
    {
        return numElements;
    }
    /**
     * The add method allows to add another node to the linked list
     * @param element accepts input for element that needs to be added
     */
    public void add(String element)
    {
        if(tail == null)
        {
            head = new StringNode(element,null);
            tail = head;
        }
        else
        {
            tail.setLink(new StringNode(element,null));
            tail = tail.getLink();
        }
        numElements++;       
    }
    /**
     * The exists method checks if a desired element is somewhere in the linked list
     * @param target accepts input for appearance of desired element
     * @return whether or not the element exists in the linked list
     */
    public boolean exists(String target)
    {
        boolean found = false;
        StringNode cursor = head;
        
        while(cursor != null && !found)
        {
            if(cursor.getData().equalsIgnoreCase(target))
                found = true;
            else
                cursor = cursor.getLink();
        }
        return found;
    }
    /**
     * The remove method allows the removal of an element in the linked list
     * @param target accepts input for removal of specific element
     * @return whether element was removed or not
     */
    public boolean remove(String target)
    {
        boolean found = false;
        StringNode cursor = head, previous = null;

        while (cursor != null && !found) 
        {
            if (cursor.getData().equalsIgnoreCase(target)) 
            {
                found = true;
            } 
            else 
            {
                previous = cursor;
                cursor = cursor.getLink();
            }
        }
        if(cursor != null && found)
        {
            if(previous == null)
                head = head.getLink();
            else
                previous.setLink(cursor.getLink());
            if(tail == cursor)
                tail = previous;
            numElements--;
        }
        return found;
    }
    /**
     * the iteratorPrototype method "copies" the linked list and passes the
     * copied linked list to a new ListerPrototype2
     *
     * @return a ListerPrototype2 using a copy of the linked list
     */
    public ListerPrototype2 iteratorPrototype() 
    {
        // declare variables
        StringNode headOfListToReturn; // beginning of new "copied" list
        StringNode cursorOfListToCopy; // active node of list to copy
        StringNode lastNodeOfListToReturn; // end of new "copied" list

        // establish the copied list
        headOfListToReturn = null;

        if (head != null) 
        {
            // create the head of the new list
            headOfListToReturn = new StringNode(head.getData(), null);
            // use lastNodeOfListToReturn as a pointer to the last node in the copied list
            lastNodeOfListToReturn = headOfListToReturn;
            // use currentCursor as the pointer to the existing list
            cursorOfListToCopy = head.getLink();
            // if we have a node...
            while (cursorOfListToCopy != null) 
            {
                // create a new node from the end of the new list
                lastNodeOfListToReturn.setLink(new StringNode(cursorOfListToCopy.getData(), null));
                // move lastNodeOfListToReturn to the new last node
                lastNodeOfListToReturn = lastNodeOfListToReturn.getLink();
                // move the cursorOfListToCopy to the next node
                cursorOfListToCopy = cursorOfListToCopy.getLink();
            }
        }
        return new ListerPrototype2(headOfListToReturn);
    }
}
