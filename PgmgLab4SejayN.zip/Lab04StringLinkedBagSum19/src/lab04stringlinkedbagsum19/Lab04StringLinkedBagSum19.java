package lab04stringlinkedbagsum19;

/**
 *
 * @author Stephen T. Brower<stephen.brower@raritanval.edu>
 */
public class Lab04StringLinkedBagSum19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StringLinkedBagSimpleTest.main(args);
    }
    
}
