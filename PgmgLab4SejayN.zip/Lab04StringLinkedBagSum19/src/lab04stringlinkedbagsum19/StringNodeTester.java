package lab04stringlinkedbagsum19;

/**
 *
 * @author Linda Yang
 */
public class StringNodeTester 
{
    public static void main(String[] args)
    {
        // Tester for StringNode class
        
        StringNode myNode = new StringNode("St. Martin", null);
        StringNode nextNode = new StringNode("St. Thomas", null);
        StringNode cursor;
        
        myNode.setLink(nextNode);
        
        cursor = myNode;
        System.out.println(cursor.getData());
        cursor = cursor.getLink();
        System.out.println(cursor.getData());
        
    }
    
}
