package lab04stringlinkedbagsum19;

/**
 *
 * @author Sejay Noupin
 */
public class StringNode 
{
    private String data;
    private StringNode link;
    
    /**
     * Constructor
     * @param initialData to set initial data of node
     * @param initialLink to set initial link of node
     */
    public StringNode(String initialData, StringNode initialLink)
    {
        data = initialData;
        link = initialLink;
    }
    /**
     * The getData method shows the element that exists in the node
     * @return the element in the node
     */
    public String getData()
    {
        return data;
    }
    /**
     * The getLink method shows what the starting node is linked to
     * @return node that is linked to starting node or null
     */
    public StringNode getLink()
    {
        return link;
    }
    /**
     * The setData method accepts input for new data in desired node
     * @param newData allows string input for new data in node
     */
    public void setData(String newData)
    {
        data = newData;
    }
    /**
     * The setLink method allows a link to be created between two nodes
     * @param newLink accepts StringNode input for new link between nodes
     */
    public void setLink(StringNode newLink)
    {
        link = newLink;
    }
}
