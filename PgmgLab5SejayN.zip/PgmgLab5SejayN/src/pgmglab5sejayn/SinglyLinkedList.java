package pgmglab5sejayn;

/**
 *
 * @author Sejay Noupin
 */
public class SinglyLinkedList<E> 
{
    private Node<E> head;
    private Node<E> tail;
    private int numElements;
    
    public SinglyLinkedList()
    {
        head = null;
        tail = null;
        numElements = 0;
    }
    
    public int getSize()
    {
        return numElements;
    }
    
    public void appendList(E newElement)
    {
        if(tail == null)
        {
            head = new Node<E>(newElement, null);
            tail = head;
        }
        else
        {
            tail.setNext(new Node<E>(newElement, null));
            tail = tail.getNext();
        }
        numElements++;
    }
    
    public void prependList(E newElement)
    {
        if(tail == null)
        {
            head = new Node<E> (newElement,null);
            tail = head;
        }
        else
        {
            head = new Node<E>(newElement, head);
        }
        numElements++;
    }
    
    public boolean exists(E target)
    {
        boolean found = false;
        Node<E> cursor = head;

        while (cursor != null && !found) 
        {
            if (cursor.getData().equals(target)) 
            {
                found = true;
            } 
            else 
            {
                cursor = cursor.getNext();
            }
        }
        return found;
    }
    
    public int countOccurences(E target)
    {
        int numOccur = 0;
        Node<E> cursor;
        
        for(cursor = head; cursor != null; cursor.getNext())
        {
            if(cursor.getData().equals(target))
                numOccur++;
        }
        return numOccur;
    }
    
    public boolean remove(E target)
    {
        boolean found = false;
        Node<E> cursor = head, previous = null;

        while (cursor != null && !found) 
        {
            if (cursor.getData().equals(target)) 
            {
                found = true;
            } 
            else 
            {
                previous = cursor;
                cursor = cursor.getNext();
            }
        }
        if (cursor != null && found) 
        {
            if (previous == null) 
            {
                head = head.getNext();
            } 
            else 
            {
                previous.setNext(cursor.getNext());
            }
            if (tail == cursor) 
            {
                tail = previous;
            }
            numElements--;
        }
        return found;
    }
    /**
     * the iteratorPrototype method "copies" the linked list and passes the
     * copied linked list to a new Lister<E>
     *
     * @return a Lister<E> using a copy of the linked list
     */
    public Lister<E> iterator() 
    {
        // declare variables
        Node headOfListToReturn; // beginning of new "copied" list
        Node cursorOfListToCopy; // active node of list to copy
        Node lastNodeOfListToReturn; // end of new "copied" list

        // establish the copied list
        headOfListToReturn = null;

        if (head != null) 
        {
            // create the head of the new list
            headOfListToReturn = new Node(head.getData(), null);
            // use lastNodeOfListToReturn as a pointer to the last node in the copied list
            lastNodeOfListToReturn = headOfListToReturn;
            // use currentCursor as the pointer to the existing list
            cursorOfListToCopy = head.getNext();
            // if we have a node...
            while (cursorOfListToCopy != null) 
            {
                // create a new node from the end of the new list
                lastNodeOfListToReturn.setNext(new Node(cursorOfListToCopy.getData(), null));
                // move lastNodeOfListToReturn to the new last node
                lastNodeOfListToReturn = lastNodeOfListToReturn.getNext();
                // move the cursorOfListToCopy to the next node
                cursorOfListToCopy = cursorOfListToCopy.getNext();
            }
        }
        return new Lister(headOfListToReturn);
    }
}
