package pgmglab5sejayn;

/**
 *
 * @author Sejay Noupin
 */
public class Node<E> 
{
    private E data;
    private Node<E> next;
    
    public Node(E initialData, Node<E> initialNext)
    {
        data = initialData;
        next = initialNext;
    }
    
    public E getData()
    {
        return data;
    }
    
    public Node<E> getNext()
    {
        return next;
    }
    
    public void setData(E newData)
    {
        data = newData;
    }
    
    public void setNext(Node<E> newNext)
    {
        next = newNext;
    }
}
