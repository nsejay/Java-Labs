package pgmglab5sejayn;

/**
 *
 * @author Sejay Noupin
 */
public class PgmgLab5SejayN 
{
    public static void main(String[] args) 
    {
        // TODO code application logic here
    }
    
}
