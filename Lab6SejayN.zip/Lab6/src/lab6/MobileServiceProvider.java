package lab6;

/**
 *
 * @author Sejay Noupin
 */
public class MobileServiceProvider 
{
    private char customerPackage;
    private int numberOfMinutesUsed;
    
    /**
     * The MobileServiceProvider constructor sets the entered parameters.
     * @param newCustomerPackage Sets the first character of possible package
     * @param newNumberOfMinutes Sets the number of minutes used by the customer.
     */
    public MobileServiceProvider (char newCustomerPackage, 
                                  int newNumberOfMinutesUsed)
    {
        customerPackage = newCustomerPackage;
        numberOfMinutesUsed = newNumberOfMinutesUsed;                
    }
    /**
     * The getCustomerPackage method returns the name
     * of the package customer selected.
     * @return mobile package
     */
    public char getCustomerPackage()
    {
        return customerPackage;
    }
    /**
     * The getNumberOfMinutesUsed method returns the minutes 
     * the customer uses.
     * @return It returns the minutes used by the customer.
     */
    public int getNumberOfMinutesUsed()
    {
        return numberOfMinutesUsed;
    }
    /**
     * The setCustomerPackage method sets the
     * entered character of the package to a variable.
     * @param newCustomerPackage allows input of customer package.
     */
    public void setCustomerPackage(char newCustomerPackage)
    {
        customerPackage = newCustomerPackage;
    }
    /**
     * The setNumberOfMinutesUsed method sets the entered minutes used by the
     * customer to a variable.
     *
     * @param newNumberOfMinutesUsed allows input for minutes customer used phone.
     */
    public void setNumberOfMinutesUsed(int newNumberOfMinutesUsed)
    {
        numberOfMinutesUsed = newNumberOfMinutesUsed;
    }
    /**
     * The totalCharges method calculates the bill based on
     * the package selected and the minutes used by the customer.
     * @return It returns the charge based on selected package and minutes used.
     */
    public double totalCharges()
    {
        if ((customerPackage == 'A' || customerPackage == 'a') 
           && (numberOfMinutesUsed <= 450))
        {
            return 39.99;
        }
        else if ((customerPackage == 'A' || customerPackage == 'a') 
                && (numberOfMinutesUsed > 450))
        {
            double result = 39.99 + (numberOfMinutesUsed - 450) * .45;
            return result;
        }
        else if ((customerPackage == 'B' || customerPackage == 'b') 
                && (numberOfMinutesUsed <= 900))
        {
            return 59.99;
        }
        else if ((customerPackage == 'B' || customerPackage == 'b')
                && (numberOfMinutesUsed > 900))
        {
            double result = 59.99 + (numberOfMinutesUsed - 900) * .40;
            return result;
        }
        else
            return 69.99;
    }
    /**
     * The toString method will display a string 
     * which neatly displays necessary data
     * @return final statement displaying plan, total minutes and cost
     */
    public String toString()
    {
        String statement = "MSP Plan:" + customerPackage 
                         + " Min.: " + numberOfMinutesUsed + " $" + totalCharges();
        
        return statement;
    }
            
}
