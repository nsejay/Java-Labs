package proglab09graphssum18;

/**
 * a minimal number of stubs have been provided 
 * to get the starting point file to run
 * 
 * @author Sejay Noupin
 * 
 */
public class WeightedGraph 
{
    private int [][] edges;
    private Object [] labels;
    
    /**
     * Constructor
     * @param n number of nodes for the graph being created
     */
    public WeightedGraph(int n)
    {
        edges = new int[n][n];
        labels = new Object[n];
    }
    /**
     * The addEdge method receives two locations and the weight of the edge
     * @param source location to receive neighbor
     * @param target location to be added as a neighbor
     * @param weight weight the edge will have
     */   
    public void addEdge(int source, int target, int weight)
    {
        edges[source][target] = weight;
    }
    /**
     * The getLabel method returns the label associated with the vertex
     * @param vertex the vertex we are seeking a label for
     * @return label of vertex
     */
    public Object getLabel(int vertex)
    {
        return labels[vertex];
    }
    /**
     * The isEdge method tells you if an edge exists between two vertices
     * @param source location to check for neighbor
     * @param target second location to be checked for a neighbor
     * @return whether or not the second location is a neighbor of the first location
     */
    public boolean isEdge(int source, int target)
    {
        if(edges[source][target] > 0)
            return true;
        else
            return false;
    }
    /**
     * The neighbors method builds an array of locations 
     * which are a neighbor of the desired vertex
     * @param vertex location to get neighbors from
     * @return an array that contains the neighbors of the vertex
     */
    public int[ ] neighbors(int vertex)
    {
        int i;
        int count;
        int [] answer;
        
        count = 0;
        for(i = 0; i < labels.length; i++)
        {
            if(edges[vertex][i] > 0)
                count++;
        }
        answer = new int[count];
        
        count = 0;
        for(i = 0; i < labels.length; i++)
        {
            if(edges[vertex][i] > 0)
                answer[count++] = i;
        }
        return answer;
    }
    /**
     * The removeEdge method removes an edge by setting the weight value to 0
     * @param source location to lose neighbor
     * @param target location to be removed as neighbor
     */
    public void removeEdge(int source, int target)
    {
        edges[source][target] = 0;
    }
    /**
     * The setLabel method assigns a label to the desired vertex
     * @param vertex vertex which to set a label for
     * @param newLabel label for the vertex
     */
    public void setLabel(int vertex, Object newLabel)
    {
        labels[vertex] = newLabel;
    }
    /**
     * The size method returns number of vertices in the graph
     * @return number of vertices
     */
    public int size( )
    {
        return labels.length;
    }
    /**
     * The getWeight method returns the weight of the specified edge
     * @param source location of one end of the edge
     * @param target location of the other end of the edge
     * @return weight of the edge
     */
    public int getWeight(int source, int target)
    {
        return edges[source][target];
    }
    /**
     * The setWeight method is to set a weight for a specified edge of the graph
     * @param source location of one end of the edge
     * @param target location of the other end of the edge
     * @param weight desired weight to make the edge
     */
    public void setWeight(int source, int target, int weight)
    {
        edges[source][target] = weight;
    }
    
    
}
