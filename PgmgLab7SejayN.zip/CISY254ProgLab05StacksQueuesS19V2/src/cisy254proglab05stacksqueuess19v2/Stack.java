package cisy254proglab05stacksqueuess19v2;

/**
 *
 * @author Sejay Noupin
 */
public class Stack<E> 
{
    private Node<E> top;
    private int numElements;
    
    /**
     * No-arg constructor initializes top to null and numElements to 0
     */
    public Stack()
    {
        top = null;
        numElements = 0;
    }
    /**
     * The push method adds an element to the stack
     * @param element desired element to be added
     */
    public void push(E element)
    {
        top = new Node<E>(element,top);
        numElements++;
    }
    /**
     * The pop method removes an element from the stack
     * @return element that was removed
     * @throws EmptyStack when stack is empty, this exception method will run
     */
    public E pop() throws EmptyStack
    {
        E value;
        
        if(top == null)
            throw new EmptyStack();
        else
        {
            value = top.getData();
            top = top.getLink();
            numElements--;
        }    
        return value;
    }
    /**
     * The size method tells you the number of elements in the stack
     * @return number of elements in the stack
     */
    public int size()
    {
        return numElements;
    }
}
