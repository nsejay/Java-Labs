package cisy254proglab05stacksqueuess19v2;

/**
 *
 * @author Sejay Noupin
 */
public class Node<E> 
{
    private E data;
    private Node<E> link;

    /**
     * Constructor
     *
     * @param initialData to set initial data of node
     * @param initialLink to set initial link of node
     */
    public Node(E initialData, Node<E> initialLink) {
        data = initialData;
        link = initialLink;
    }

    /**
     * The getData method retrieves the element inside the node
     *
     * @return the element in the node
     */
    public E getData() {
        return data;
    }

    /**
     * The getLink method retrieves the node that the starting node is linked to
     *
     * @return the node that starting node is linked to or null
     */
    public Node<E> getLink() {
        return link;
    }

    /**
     * The setData method accepts input for data to be entered into node
     *
     * @param newData allows input for data into node
     */
    public void setData(E newData) {
        data = newData;
    }

    /**
     * The setLink method allows a link between two nodes to be created
     *
     * @param newLink allows specification of desired node to be linked
     */
    public void setLink(Node<E> newLink) {
        link = newLink;
    }    
}
