package cisy254proglab05stacksqueuess19v2;

/**
 *
 * @author ???
 */
public class Queue<E> 
{
    private Node<E> front;
    private Node<E> rear;
    private int numElements;
    
    /**
     * 
     */
    public Queue()
    {
        front = null;
        rear = null;
        numElements = 0;
    }
    /**
     * 
     * @param element 
     */
    public void add(E element)
    {
        if(rear == null)
        {
            front = new Node<E>(element,null);
            rear = front;
        }
        else
        {
            rear.setLink(new Node<E>(element,null));
            rear = rear.getLink();
        }
        numElements++;
    }
    
    public E remove() throws EmptyQueue
    {
        E value;
        if(front == null)
            throw new EmptyQueue();
        else
        {
            value = front.getData();
            if(front != rear)
                front = front.getLink();
            else
                front = rear = null;
            numElements--;
        }
        return value;
    }
    
    public int size()
    {
        return numElements;
    }
}
