package project3sejayn;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author Sejay Noupin
 */
public class Project3SejayN 
{

    public static void main(String[] args) 
    {
        int numDaisies = 0;
        int numDaisiesGathered = 0;
        int gatheredDaisies;
        int numJumps = 0;
        String choice;

        Grid gameBoard = new Grid();
        Scanner keyboard = new Scanner(System.in);

        do 
        {
            System.out.printf("You are in spot [%d, %d]\n",
                    gameBoard.getCurrentRow(), gameBoard.getCurrentCol());
            System.out.println("There are " + gameBoard.getCurrentValue()
                    + " daises located here");
            System.out.printf("\nYou currently have a total of %,d daisies", numDaisies);
            System.out.print("\nWhat would you like to do? (G, J, N, "
                    + "S, E, W, M, Q): ");
            choice = keyboard.nextLine();

            if (choice.equalsIgnoreCase("G")) 
            {
                gatheredDaisies = gameBoard.gatherDaisies();
                System.out.println("\nYou just gathered "
                        + gatheredDaisies + " daisies from the spot\n");
                numDaisies += gatheredDaisies;
                numDaisiesGathered++;
            } 
            else if (choice.equalsIgnoreCase("J")) 
            {
                gameBoard.jump();
                numJumps++;
                System.out.println();
            } 
            else if (choice.equalsIgnoreCase("N"))
                gameBoard.goNorth();
            else if (choice.equalsIgnoreCase("S"))
                gameBoard.goSouth();
            else if (choice.equalsIgnoreCase("E"))
                gameBoard.goEast();
            else if (choice.equalsIgnoreCase("W"))
                gameBoard.goWest();
            else if (choice.equalsIgnoreCase("M"))
            {
                System.out.println("\nMap of Grid:");
                System.out.println(gameBoard);
                System.out.println();
            } 
            else 
            {
                System.out.printf("\nYou gathered a total of %,d daisies!", numDaisies);
                System.out.println("\nYou did it in " + numJumps + " jumps and "
                        + numDaisiesGathered + " number of gatherings");
            }
        } while (choice.charAt(0) != 'Q' && choice.charAt(0) != 'q');
    }     
}