//Sejay Noupin
package lab3;
public class Food 
{
    private int calories;
    private String description;
    
    /**
     * The Food constructor accepts arguments for what
     * the food is and the amount of calories it has.
     * @param newDescription This is for the initial value of the food. 
     * @param newCalories    This is for the initial amount 
     *                       of calories in the food.
     */
    public Food(String newDescription,int newCalories)
    {
        description = newDescription;
        calories = newCalories;
    }

    /**
     * The setDescription method allows input for what the food is.
     * @param newDescription This is for the initial value of the food.
     */
    public void setDescription(String newDescription)
    {
        description = newDescription;
    }
    
    /**
     * The setCalories method allows input for how many calories the food has.
     * @param newCalories This is the initial value
     *                    of the amount of calories.
     */
    public void setCalories(int newCalories)
    {
        calories = newCalories;
    }
    /**
     * The getDescription method is to retrieve the input value of the food.
     * @return The requested food.
     */
    public String getDescription()
    {
        return description;
    }
    
    /**
     * The getCalories method is to retrieve the input value for calories.
     * @return The calories contained in the food.
     */
    public int getCalories()
    {
        return calories;
    }
}
