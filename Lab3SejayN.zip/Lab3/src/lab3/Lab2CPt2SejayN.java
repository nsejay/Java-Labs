//Sejay Noupin
package lab3;
import java.util.Scanner;

public class Lab2CPt2SejayN 
{
    public static void main(String[] args) 
    {
        int bunnies;
        int points;
        double pointsPerBunny;
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.print("How many bunnies were launched? ");
        bunnies = keyboard.nextInt();
        System.out.print("How many points were earned? ");
        points = keyboard.nextInt();
        
        pointsPerBunny = (double)points / (double)bunnies;
        
        System.out.printf("\n%,d Points for %,d bunnies = %,.1f points/bunny\n" 
                          ,points, bunnies, pointsPerBunny);
    }  
}
