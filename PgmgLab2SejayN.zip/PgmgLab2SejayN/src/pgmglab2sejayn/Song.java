package pgmglab2sejayn;

/**
 *
 * @author Sejay Noupin
 */
public class Song 
{
    private String songTitle;
    private String artist;
    private int lengthInSeconds;
    
    /**
     * The Song Constructor has three arguments that requires entered parameters
     * @param initialSongTitle name of Song
     * @param initialArtist name of Artist
     * @param initialLengthInSeconds duration of song in seconds
     */
    public Song (String initialSongTitle, String initialArtist, int initialLengthInSeconds)
    {
        songTitle = initialSongTitle;
        artist = initialArtist;
        lengthInSeconds = initialLengthInSeconds;
    }
    
    /**
     * The getSongTitle method returns the title of the Song
     * @return title of song
     */
    public String getSongTitle()
    {
        return songTitle;
    }
    
    /**
     * The getArtist method returns the name of the Artist
     * @return name of Artist
     */
    public String getArtist()
    {
        return artist;
    }
    
    /**
     * The getLengthInSeconds method returns the duration of the song in seconds
     * @return duration of song in seconds
     */
    public int getLengthInSeconds()
    {
        return lengthInSeconds;
    }
    
    /**
     * The setSongTitle method allows input for name of song
     * @param newSongTitle name of song
     */
    public void setSongTitle(String newSongTitle)
    {
        songTitle = newSongTitle;
    }
    
    /**
     * The setArtist method allows input for name of Artist
     * @param initialArtist  name of artist
     */
    public void setArtist(String initialArtist)
    {
        artist = initialArtist;
    }
    
    /**
     * The setLengthInSeconds method allows input for length of Song in seconds
     * @param initialLengthInSeconds duration of song in seconds
     */
    public void setLengthInSeconds(int initialLengthInSeconds)
    {
        lengthInSeconds = initialLengthInSeconds;
    }
}
