package pgmglab2sejayn;
import java.util.Scanner;
/**
 *
 * @author Sejay Noupin
 */
public class SongList 
{
    public static void main(String[] args) 
    {
        String nameOfSong, nameOfArtist;
        int lengthOfSong, i, s = 0;

        Song[] mySongList = new Song[5];
        Scanner input = new Scanner(System.in);

        System.out.print("Enter song title (xxx to stop) for song " + s + ": ");
        nameOfSong = input.nextLine();

        if ((nameOfSong.equalsIgnoreCase("xxx"))) 
        {
            System.out.println("\nNo songs entered");
        } 
        else 
        {
            while (!(nameOfSong.equalsIgnoreCase("xxx"))
                    && (s < mySongList.length)) 
            {
                System.out.print("Enter artist for song " + s + ": ");
                nameOfArtist = input.nextLine();

                System.out.print("Enter length in seconds for song "
                        + s + ": ");
                lengthOfSong = input.nextInt();
                input.nextLine();

                while (lengthOfSong <= 0) 
                {
                    System.out.println("\nlength must be at least 1 second\n");
                    System.out.print("Enter length in seconds for song "
                            + s + ": ");
                    lengthOfSong = input.nextInt();
                    input.nextLine();
                }

                mySongList[s] = new Song(nameOfSong, nameOfArtist, lengthOfSong);
                s++;

                if (s < mySongList.length) 
                {
                    System.out.print("\nEnter song title (xxx to stop) for"
                            + " song " + s + ": ");
                    nameOfSong = input.nextLine();
                } 
                else 
                {
                    System.out.println("\nArray is full");
                }
            }
        }
        
        if (s > 0) 
        {
            System.out.printf("\n%-30s %-30s %3s\n", "Song Title",
                    "Artist", "Len");
            for (i = 0; i < s; i++) 
            {
                System.out.printf("%-30s %-30s %3s\n",
                        mySongList[i].getSongTitle(), mySongList[i].getArtist(),
                        mySongList[i].getLengthInSeconds());
            }
        }  
    }
}
