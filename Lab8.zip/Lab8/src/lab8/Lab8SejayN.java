package lab8;
import java.util.ArrayList;  
/**
 *
 * @authors Sejay Noupin, Neel Patel
 */
public class Lab8SejayN
{
   public static void main(String[] args)
   {
      ArrayList<InventoryItem> list = new ArrayList<InventoryItem>();
      
      list.add(new InventoryItem("Hammers", 105));
      list.add(new InventoryItem("Nails", 1200));
      list.add(new InventoryItem("Saws", 12));
      list.add(new InventoryItem("Tires", 32));
      list.add(new InventoryItem("Vaccuums", 6));
      list.add(new InventoryItem("Cement", 300));
      list.add(new InventoryItem("Metal Sheets", 16));
      list.add(new InventoryItem("Shears", 22));
      
      System.out.println("Original Inventory List:");
      System.out.printf("%s %-14s %4s\n", "Index", "Description", "Units");
      System.out.println();
      
      for (int index = 0; index < list.size(); index++)
      {
         InventoryItem item = (InventoryItem)list.get(index);
         System.out.printf("%-5d %-15s %4d\n",index, 
                           item.getDescription(), item.getUnits());
      }
      
      list.remove(0);
      list.remove(0);
      list.remove(0);
      
      System.out.println("\nFirst Three Items Removed:");
      System.out.printf("%s %-14s %4s\n", "Index", "Description", "Units");
      System.out.println();
      
      for (int index = 0; index < list.size(); index++)
      {
         InventoryItem item = (InventoryItem)list.get(index);
         System.out.printf("%-5d %-15s %4d\n",index, 
                           item.getDescription(), item.getUnits());
      }
      
      list.set(4, new InventoryItem("Shower Heads", 69));
      
       System.out.println("\nLast Item Replaced:");
       System.out.printf("%s %-14s %4s\n", "Index", "Description", "Units");
       System.out.println();

       for (int index = 0; index < list.size(); index++) {
           InventoryItem item = (InventoryItem) list.get(index);
           System.out.printf("%-5d %-15s %4d\n", index,
                             item.getDescription(), item.getUnits());
       }
   }
}